//
//  EMCallRemoteView.h
//  HyphenateSDK
//
//  Created by XieYajie on 2/29/16.
//  Copyright © 2016 easemob.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMCallRemoteView : UIView

- (instancetype)initWithFrame:(CGRect)frame;

@end
